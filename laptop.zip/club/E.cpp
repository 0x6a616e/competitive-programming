#include <iostream>
#include <cmath>

int main() {
        double a, b;
        std::cin >> a >> b;
        std::cout << std::ceil(a / b) << std::endl;
}
