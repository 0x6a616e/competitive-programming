#include <iostream>
#include <vector>
#include <algorithm>
#include <set>

using namespace std;

vector<int> Ri;
set<int> visitados;

int solve(int L, int U, int c) {
        if (visitados.find(L) != visitados.end())
                return 99999999;
        visitados.insert(L);
        int minimo = 0, s;
        if (L == U)
                return c;
        for (int i = 0; i < Ri.size(); i++) {
                s = solve((L + Ri[i]) % 10000, U, c + 1);
                minimo = (minimo == 0 ? s : min(s, minimo));
        }

        return minimo;
}

int main()
{
        int L, U, R;

        while (cin >> L >> U >> R && !(L == 0 && U == 0 && R == 0)) {
                Ri.clear();
                Ri.resize(R, 0);
                visitados.clear();
                for (int i = 0; i < R; i++)
                        cin >> Ri[i];
                cout << solve(L, U, 0) << '\n';
        }

        return 0;
}
