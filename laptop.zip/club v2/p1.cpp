// Encuentra cuantos 4 hay en cada número entero

#include <iostream>

using namespace std;

int main()
{
        int T, c;
        string N;
        cin >> T;

        while (T--) {
                c = 0;
                cin >> N;
                for (int i = 0; i < N.size(); i++)
                        if (N[i] == '4')
                                c++;
                cout << c << '\n';
        }
        
        return 0;
}
